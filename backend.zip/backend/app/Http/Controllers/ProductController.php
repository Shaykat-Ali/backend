<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use Illuminate\Support\Facades\Auth;
use App\User;
use Validator;

class ProductController extends Controller
{
	protected $user;
    public function __construct(){
        $this->middleware('auth:api');
        $this->user = $this->guard()->user();
    } 

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $products = $this->user->product()->get(['title','description','price','image','created_by']);
        return response()->json($products->toArray());
    }

    
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all() , [
             'title' => 'required|string',
             'description' => 'required|string',
             'price' => 'required',
             'image' => 'required'

        ]);
        if($validator->fails()){
            return response()->json([
             'status' => false,   
             'errors' => $validator->errors()
            ],400);
        }

        $product = new Product();
        $product->fill($request->all());
        if($request->hasFile('image')){
            $product->image = $request->file('image')
                ->move('public/upload/product_image/', str_random(40) . '.' . $request->image->extension());
        }

        if($this->user->product()->save($product)) {
          return response()->json([
              'status' => true,
              'product' => $product
          ]);
        } else {
          return response()->json([
              'status' => false,
              'message' => 'Oops , Product Could not be saved.'
          ]);  
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product)
    {
        return $product;
    }

    
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Product $product)
    {
        $validator = Validator::make($request->all() , [
             'title' => 'required|string',
             'description' => 'required|string',
             'price' => 'required',
             'image' => 'required'

        ]);

        if($validator->fails()){
            return response()->json([
             'status' => false,   
             'errors' => $validator->errors()
            ],400);
        }

        $product->fill($request->all());
        if($request->hasFile('image')){
            if ($product->image != null){
                 $this->deleteFile($product->image);
            }
                $product->image = $request->file('image')
                   ->move('public/upload/user_image/', str_random(40) . '.' . $request->image->extension());
        }
        if($this->user->product()->save($product)) {
          return response()->json([
              'status' => true,
              'product' => $product
          ]);
        } else {
          return response()->json([
              'status' => false,
              'message' => 'Oops , Product Could not be updated.'
          ]);  
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product $product)
    {
        if($product->delete()){
            return response()->json([
              'status' => true,
              'product' => $product,
           ]);
        } else {
          return response()->json([
              'status' => false,
              'message' => 'Oops , Product Could not be deleted.'
          ]);  
        }
    }


    private function deleteFile($path)
    {
        File::delete($path);
    }

    protected function guard(){
        return Auth::guard(); 
    }
    
}
